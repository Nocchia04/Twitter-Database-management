import re

def inserimento_frase():
    text = input("Inserisci una frase: ")
    return text

def occorrenze_prima_persona(text):
    regx= r"\S+[rtpsdfglcvbnomz]io|\S+[rtpsdfglcvbnmz]o"
    arr = re.findall(regx, text)
    return(len(arr))

if __name__ == "__main__":
    frase = inserimento_frase()
    print("Sono presenti ", occorrenze_prima_persona(frase), "verbi in prima persona.")
    
