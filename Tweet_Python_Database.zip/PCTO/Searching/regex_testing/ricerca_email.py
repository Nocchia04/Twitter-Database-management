from doctest import testmod
import re
from tkinter import Text

def find_email(text):
    x= re.findall(r"\S+@+[a-z]+\.+\S+", text) 
    return (len(x))

if __name__ == "__main__":
    text = input("Inserisci una frase, verificher< se ci sono email all'interno: ")
    print("Sono stati trovate ", find_email(text), " email.")
    
