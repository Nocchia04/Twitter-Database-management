import logging

from ricerca_email import *
from occorrenze_2o3_caratteri import *
from personalita_egoiste import *
from caratteri_speciali import *
from verbi_prima_persona import *
from recupero_url import *
from menzioni_twitter import *
from ricorrenza_hashtag import *

class Unittestregex:
    def test_email():
        try:
            assert find_email("In questa frase è presente apannocchia04@gmail.com") ==  1, "Errore durante il test numero 1"
            assert find_email("apannocchia04@gmai.copm è presente nella frase") ==  1, "Errore durante il test numero 2"
            assert find_email("apannocchia04@gmail.com") ==  1, "Errore durante il test numero 3"
            assert find_email("apannocchia04@gmail.com beamon70@outlook.it") ==  2, "Errore durante il test numero 4"
            assert find_email("beamon70@outlook.it In questa frase è presente apannocchia04@gmail.com") ==  2, "Errore durante il test numero 5"
            logging.info("Test sulla ricerca di indirizzi email passato")
        except:
            logging.error("errore durante i test sulla ricerca degli indirizzi email")
        
    def test_occorrenze():
        try:
            assert calcolo_occorrenze("sse") == 1, "Errore durante il test numero 1"
            assert calcolo_occorrenze("se") == 1, "Errore durante il test numero 2"
            assert calcolo_occorrenze("to") == 4, "Errore durante il test numero 3"
            assert calcolo_occorrenze("ta") == 1, "Errore durante il test numero 4"
            assert calcolo_occorrenze("") == 22, "Errore durante il test numero 5"
            logging.info("test sulle occorrenze a 2/3 lettere passato")
        except:
            logging.error("Errore durante i test sulle occorrenze a tre letter")
        
    def occorrenze_egoisti():
        try:
            assert controllo_occorrenze("io mangio io bevo io fumo") == 3, "Errore durante il test numero 1"
            assert controllo_occorrenze("io") == 1, "Errore durante il test numero 2" 
            assert controllo_occorrenze("io msnhio io bevo io fumo pure io") == 4, "Errore durante il test numero 3"
            assert controllo_occorrenze("io mangio tu bevi ionico fuma") == 1, "Errore durante il test numero 4"
            assert controllo_occorrenze("io invento io,") == 2, "Errore durante il test numero 5"
            logging.info("test sulle personalità egoiste passato")
        except:
            logging.error("Errore durante il test sulle personalità egoiste")    
    def test_caratteri_speciali():
        try:
            assert conta_caratteri_speciali("Marco + aurora") == 1, "Errore durante il test numero 1"
            assert conta_caratteri_speciali("(Marco) - (aurora)") == 5, "Errore durante il test numero 2"
            assert conta_caratteri_speciali("{{{{{Marco + aurora}}}}}") == 11, "Errore durante il test numero 3"
            assert conta_caratteri_speciali("{{{{{|||||}}}}}") == 15, "Errore durante il test numero 4"
            assert conta_caratteri_speciali("Marco - aurora + giulio - martina $ 2 .") == 5, "Errore durante il test numero 5"
            logging.info("Test sui caratteri speciali passato")
        except:
            logging.error("Errore durante il test sui caratteri speciali")
            
        
    def verbi_prima_persona():
        try: 
            assert occorrenze_prima_persona("io mangio tu bevi egli gioca") == 1, "Errore durante il test numero 1"
            assert occorrenze_prima_persona("io sono voglio mangio") == 3, "Errore durante il test numero 2"
            assert occorrenze_prima_persona("mangio bevi dormo faccio resto dico") == 5, "Errore durante il test numero 3"
            assert occorrenze_prima_persona("bevi mangi dormi nasci cresci muori") == 0, "Errore durante il test numero 4"
            assert occorrenze_prima_persona("muori muoio") == 1, "Errore durante il test numero 5"
            logging.info("Test sui verbi in prima persona passato")
        except:
            logging.error("Errore durannte il test sui verbi in prima persona")
        
    def test_trova_url():
        try:
            assert trova_url("https://wikipedia.org") == 1, "Errore durante il test nmero 1"
            assert trova_url("testo a caso https://wikipedia.org testo a caso ancora") == 1, "Errore durante il test nmero 2"
            assert trova_url("https://wikipedia.org https://wikipedia.org") == 2, "Errore durante il test nmero 3"
            assert trova_url("cerca https://wikipedia.org anziche https://pippo.com") == 2, "Errore durante il test nmero 4"
            assert trova_url("wikipedia.org") == 0, "Errore durante il test nmero 5"
            logging.info("Test sugli url passato")
        except:
            logging.error("Errore durante il test sugli URL")    
    def test_menzioni_twitter():
        try:
            assert cerca_menzioni("@John", "@john") == 1, "Errore duranre il test numero 1"
            assert cerca_menzioni("@John ama passare i pomeriggi con @luca", "@luca") == 1, "Errore duranre il test numero 2"
            assert cerca_menzioni("@luca @john e @giuia sono amici strettissimi", "@giulia") == 1, "Errore duranre il test numero 1"  
            assert cerca_menzioni("@john sta lavorando a @john", "@john") == 2, "Errore duranre il test numero 1"
            assert cerca_menzioni("@anna @marco @giulio @armando", "@anna") == 1, "Errore duranre il test numero 1"
            logging.info("Test sulle menzioni passato")
        except:
            logging.error("Errore durante il test sulle menzioni")
        
    def test_menzioni_twitter():
        try:
            assert cerca_hashtag("#ciao", "#ciao") == 1, "Errore duranre il test numero 1"
            assert cerca_hashtag("#ciao", "#pippo") == 0, "Errore duranre il test numero 2"
            assert cerca_hashtag("#wow", "#wow #wow") == 2, "Errore duranre il test numero 3"
            assert cerca_hashtag("#ciao", "#ciaomondo") == 0, "Errore duranre il test numero 4"
            assert cerca_hashtag("#ciao", "ciao #ciao dico #ciao") == 2, "Errore duranre il test numero 5"
            logging.info("Test sulle menzioni passato")
        except:
            logging.error("Errore durante il test delle menzioni")   
    
if __name__ == '__main__':
    
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename='occurences.log')      #configuration of logs
    logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename='occurrences.log')
    
    Unittestregex.test_email()
    Unittestregex.test_occorrenze()
    Unittestregex.occorrenze_egoisti()
    Unittestregex.test_caratteri_speciali()
    Unittestregex.verbi_prima_persona()
    Unittestregex.test_trova_url()
    Unittestregex.test_menzioni_twitter()
    Unittestregex.test_menzioni_twitter()
    