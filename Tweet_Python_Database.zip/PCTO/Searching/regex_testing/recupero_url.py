import re

def trova_url(text):
    regx = r"\s+https[:][/][/]+[a-z]+\.+\S+|^https[:][/][/]+[a-z]+\.+\S+"
    arr = re.findall(regx, text)
    return(len(arr))
    
if __name__ == '__main__':
    text = input("Inserisci il testo, il numero di URL verrà estratto: ")
    url = input("Inserisci l'url del quale vuoi cercare le ricorrenze: ")
    print("Sono stati trovati ", trova_url(text, url), " URL.")