import re

def controllo_occorrenze(text):
    arr = re.findall(r"(?i)\s+io+\s+|^io+\s|\s+io+[,]|^io$| io$", text)
    return(len(arr))
    
if __name__ == "__main__":
    text = input("Inserisci una frase: ")
    print("Ho trovato", controllo_occorrenze(text), " volte la parola 'io'")