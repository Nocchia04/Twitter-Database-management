import pymongo
from bson.json_util import dumps as d
import json

client = pymongo.MongoClient();
mydb = client["twitterdb"]
mycol = mydb["tweets"]
text = input("Inserisci il testo che vuoi cercare: ")
regx = '^'+text+'*.'
print(regx)
cursor = mycol.find({'text': {'$regex': regx}})
list_cursor = list(cursor)
json_data = []
json_data = d(list_cursor, indent=2)
print(json_data[0])

