import re

def cerca_hashtag(hashtag, text):
    regx = r"(?i)\s+"+hashtag+r"+\s+|^"+hashtag+r"\s|^"+hashtag+r"$|"+hashtag+r"$"
    #\s+[#]+ciao+\S+|^+[#]+ciao+\S+
    arr = re.findall(regx, text)
    return(len(arr))

if __name__ == '__main__':
    text = input("Inserisci un testo: ")
    hashtag = input("Inserisci l'hashtag che vuoi cercare all'interno di questo testo: ")
    print("Il tuo hashtag appare", cerca_hashtag(hashtag, text), " volte.")