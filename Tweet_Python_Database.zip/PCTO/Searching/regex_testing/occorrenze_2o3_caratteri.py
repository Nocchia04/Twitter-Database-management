import re 


def inserisci_sottostringa():
    x = input("Inserisci la sottostringa di cui vuoi calcolare le occorrenze: ")
    if len(x) >= 2 or len(x) <=3:
        return x
    else:
        print("Errore: la sottostringa è o troppo lunga o troppo corta!")
        
def calcolo_occorrenze(x):
    frase = "Anch'io, ho visto cinque leonesse bere intorno al tegame a mezzo isolato di distanza, ho fatto un'uccisione dietro la terra R. #SafariLive"
    regx = r'\S+'+x
    occ = re.findall(regx, frase)
    return(len(occ))


if __name__ == '__main__':
    x = inserisci_sottostringa()
    res = calcolo_occorrenze(x)
    print("L'ordine di parole è presente ", res, " volte.")

