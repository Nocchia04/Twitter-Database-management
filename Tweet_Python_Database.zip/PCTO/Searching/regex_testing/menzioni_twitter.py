import re

def cerca_menzioni(text, nome):
    regx =  r"(?i)\s+"+nome+r"+\s+|^"+nome+r"\s|^"+nome+r"$|"+nome+r"$"  
    arr = re.findall(regx, text)
    return(len(arr))

if __name__ == '__main__':
    text = input("Inserisci un testo: ")
    nome = input("Inserisci il nome: ")
    print("Sono state trovate", cerca_menzioni(text, nome), "dell' utente.")