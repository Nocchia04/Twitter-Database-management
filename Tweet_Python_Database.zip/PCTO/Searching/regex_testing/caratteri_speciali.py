import re

def inserimento_frase():
    text = input("Inserisci la frase di cui vorresti vedere i caratteri speciali: ")
    return text
    
def conta_caratteri_speciali(text):
    regx= r"\[|[+]|[-]|[*]|[.]|[|]|[(]|[)]|[$]|[}]|[{]|]"
    arr = re.findall(regx, text)
    return(len(arr))

if __name__ == '__main__':
    frase = inserimento_frase()
    print("Sono presenti ", conta_caratteri_speciali(frase), " nel testo che hai dato.")