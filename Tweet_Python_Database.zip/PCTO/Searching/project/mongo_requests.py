import pymongo
from pandas import DataFrame as df

def get_users():
    user_list = []
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    user_collection = mydb["users"]
    cursor = user_collection.find()
    list_cursor=list(cursor)
    data = df(list_cursor)
    for name in data["name"]:
        user_list.append(name)
    return user_list

def get_plots():
    plot_list = []
    client = pymongo.MongoClient()
    mydb = client["twitterdb"]
    plot_collection = mydb["plots"]
    cursor = plot_collection.find()
    list_cursor = list(cursor)
    data = df(list_cursor)
    for plot in data["plot"]:
        plot_list.append(plot)
    return plot_list
    

def get_data_from_mongo():
    user_list = get_users()
    plot_list = get_plots()
    
    return user_list, plot_list