from importlib.metadata import entry_points
import tempfile
from tkinter import *
import tkinter as tk

from requests import request

def choose_plots(plot_list):
    
    root = Tk()
    root.geometry("500x500")
    choosen_plot = StringVar()
    radio_buttons = []
    
    def submit_plot():
        global final_plot
        tmp = choosen_plot.get()
        final_plot = tmp
        root.destroy()
        
    counter = 2
    for plot in plot_list:
        btn = Radiobutton(root, text=plot, variable=choosen_plot, value = plot)
        btn.grid(column=2, row=counter, sticky="W",)
        radio_buttons.append(btn) 
        counter +=2  
        
    next_button = Button(root, text="Next", command=submit_plot)
    next_button.grid()
    
    root.mainloop()
    
    
def choose_users(user_list):
    root = Tk()
    root.geometry('500x500')
    check_buttons = []
    choosen_users = []
    counter = 0
    
    def submit_users():
        global final_users
        final_users = []
        for user in choosen_users:
            tmp = user.get()
            final_users.append(tmp)
        root.destroy()
            
                
    for user in user_list:
        choosen_users.append(StringVar())
        btn = Checkbutton(root, text=user, variable=choosen_users[counter], onvalue=user, offvalue="")
        btn.grid(column=2, row=counter, sticky="W",)
        check_buttons.append(btn)
        counter+=1
    
    next_button = Button(root, text="Next", command=submit_users)
    next_button.grid()

    root.mainloop()


def starting_gui(users, plots):
    choose_plots(plots)
    choose_users(users)
    return final_users, final_plot

def ask_for_input():
    
    def submit():
        global request
        tmp = entry.get()
        request = tmp
        print(request)
        root.destroy()
    
    root = Tk()
    root.geometry('500x500')
    text_input = Label(root, text="Inserisci il campo mancante")
    entry = Entry(root)
    text_input.grid(row = 0, column = 0)
    entry.grid(row = 0, column = 3)
    next_button = Button(root, text="Next", command=submit)
    next_button.grid()
    
    root.mainloop()
    return request

