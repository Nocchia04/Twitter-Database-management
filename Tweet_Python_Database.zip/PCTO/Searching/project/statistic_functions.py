import pymongo
from receive_inputs import *

def search_on_mongo(regx, user, mycol):
    counter = mycol.count_documents({'text': {'$regex': regx}, 'name': user} )
    return counter

def url_request(users):
    url = ask_for_input()
    regx = r"(?i)\s+"+url+r"+\s+|^"+url+r"\s|^"+url+r"$|"+url+r"$"
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    mycol = mydb["tweets"]
    data  = []
    for user in users:
        data.append(search_on_mongo(regx, user, mycol))
    return data

def hashtag_request(users):
    hashtag = ask_for_input()
    regx = r"(?i)\s+"+hashtag+r"+\s+|^"+hashtag+r"\s|^"+hashtag+r"$|"+hashtag+r"$"
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    mycol = mydb["tweets"]
    data  = []
    for user in users:
        data.append(search_on_mongo(regx, user, mycol))
    return data

def mentions_request(users):
    mentions = ask_for_input()
    regx = r"(?i)\s+"+mentions+r"+\s+|^"+mentions+r"\s|^"+mentions+r"$|"+mentions+r"$"
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    mycol = mydb["tweets"]
    data  = []
    for user in users:
        data.append(search_on_mongo(regx, user, mycol)) 
    return data

def keyword_request(users):
    keyword = ask_for_input()
    regx = r"(?i)\s+"+keyword+r"+\s+|^"+keyword+r"\s|^"+keyword+r"$|"+keyword+r"$"
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    mycol = mydb["tweets"]
    data  = []
    for user in users:
        data.append(search_on_mongo(regx, user, mycol))
    return data

def emails_request(users):
    regx = r"\S+@+[a-z]+\.+\S+"
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    mycol = mydb["tweets"]
    data  = []
    for user in users:
        data.append(search_on_mongo(regx, user, mycol))
    return data

def special_request(users):
    regx = r"\[|[+]|[-]|[*]|[.]|[|]|[(]|[)]|[$]|[}]|[{]|]"
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    mycol = mydb["tweets"]
    data  = []
    for user in users:
        data.append(search_on_mongo(regx, user, mycol))
    return data

def i_word_request(users):
    regx =  r"\s+I+\s+|^I+\s|\s+I+[,]|^I$| I$"
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    mycol = mydb["tweets"]
    data  = []
    for user in users:
        data.append(search_on_mongo(regx, user, mycol))
    return data



        