from receive_inputs import *
from mongo_requests import *
from statistic_functions import *
import matplotlib.pyplot as plt
import logging

def clean(users):
    final_user_list = []
    for user in users:
        if user != "":
            final_user_list.append(user)
    
    return final_user_list

def plot_results(users, data):
    plt.bar(users, data)
    plt.show()

if __name__ == '__main__':
    
        
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename='project.log')
    logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename='project.log')
    
    try:
        user_list, plot_list = get_data_from_mongo()
        logging.info("Lista di utenti e grafici caricata con successo")
    except:
        logging.error("Errore durante il caricamnto della lista di utenti e grafici.")
    try:
        not_clean_users, plot = starting_gui(user_list, plot_list)
        logging.info("Gui caricata con successo")
    except:
        logging.error("Errore durante il caricamento della GUI")
    try:
        users = clean(not_clean_users)
        logging.info("Array 'utenti' pulico correttamente")
    except:
        logging.error("Errore durante la pulizia dell'array 'utenti'")
    data = []
    try:
        if plot == 'url':
            data = url_request(users)
        if plot == 'hashtag':
            data = hashtag_request(users)
        if plot == 'mentions':
            data = mentions_request(users)
        if plot == 'keyword':
            data = keyword_request(users)
        if plot == 'emails':
            data = emails_request(users)
        if plot == 'specials':
            data = special_request(users)
        if plot == 'i word':
            data = i_word_request(users)
        logging.info("Dati trovati correttamente")
    except:
        logging.error("Errore durante il caricamento dei dati")
    try:
        plot_results(users, data)
        logging.info("Grafico illustrato correttamente")
    except:
        logging.error("Errore durante l'illustazione del grafico")