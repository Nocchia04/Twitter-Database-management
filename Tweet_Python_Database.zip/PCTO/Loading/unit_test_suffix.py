from main import *

def test_suffx():
    assert find_suffix(r"C:\Users\beamo\Desktop\PCTO\data.json") == ".json", "Dovrebbe essere json"
    assert find_suffix(r"C:\Users\beamo\Desktop\PCTO\data.csv") == ".csv", "Dovrebbe esssere csv"
    assert find_suffix(r"C:\Users\beamo\Desktop\PCTO\prova.csv") == ".csv", "dovrebbe essere csv"
    assert find_suffix(r"C:\Users\beamo\Desktop\PCTO\prova.xml") == ".xml", "dovrebbe essere xml"
    
if __name__ == '__main__':
    test_suffx()
    print("Everything passed")