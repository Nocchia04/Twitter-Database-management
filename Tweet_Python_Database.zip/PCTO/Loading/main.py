import pymongo
import json, csv
from tkinter import *
from tkinter.filedialog import  askopenfilename
import pathlib
import logging
import pandas as pd


def search_file():
    try:
        file = askopenfilename()
        logging.info("file successfully found!!")
    except:
        logging.info("the file has not been found!!")
    
    return file


def check_if_format_is_good(data, file):
    csv_file = pd.read_csv(file)
    print(data)
    print(csv_file)
    json_length = len(data[0])
    csv_rows=len(csv_file.axes[0])
    if json_length == csv_rows:
        logging.error("An error occurred during the conversion of the file!")
    
    



def find_suffix(file):
    try:
        suffix = pathlib.Path(file).suffix
        logging.info("The suffix has been identified!!")
    except:
        logging.error("The suffix of the file has not been identified!!")
        suffix = ''
    
    return suffix



def extract_data(suffix, file):
    if suffix == ".json":
        data = load_json(file)
        if data == []:
            logging.warning("Pay attention, you are inserting an empty file on the database!!")
    else:
        if suffix == ".csv":
            data = load_csv(file)
            if data == []:
                logging.warning("Pay attention, you are inserting an empty file on the database!!")
            check_if_format_is_good(data, file)
        else:
            logging.warning("The file suffix you are using is incompatible!")                                                                        #error indication if the file suffix is incompatible
            logging.info("Please use only .JSON or .CSV files")
            data = []
    
    return data
        
            
            
def load_json(filename):
    
    
    logging.info("Starting to read the JSON file")
    
    data = []
    
    try:
        with open(filename) as f:
            data = json.load(f)
        logging.info("Data successfully read from the json file!!")                                                                                   #reading the json file
    except:
        logging.error("Error reading JSON file")
    
    return data



def load_csv(filename):
        
    logging.info("Startiing to read CSV file")
    
    data = []
    
    try:
        with open(filename, encoding="mbcs") as f:
            reader = csv.DictReader(f)                                                                                                                #reading the csv file
            for row in reader:
                data.append(row)
        logging.info("Data successfully read from the csv file!")
    except:
        logging.error("Error reading CSV")
    
    return data



def load_to_database(data):
    client = pymongo.MongoClient();
    mydb = client["twitterdb"]
    mycol = mydb["tweets"]
    counter=0
    for docs in data:
        mycol.update_many(
            {
                '_unit_id': data[counter]['_unit_id']
            },
            { '$setOnInsert':docs},
            upsert=True
        )
        counter+=1
    
    logging.info("The data has been added successfully to the database!")
        


if __name__ == "__main__":
    
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename='app.log')      #configuration of logs
    logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', filename='app.log')
    
    data = []
    file = search_file()
    suffix = find_suffix(file)
    data = extract_data(suffix, file)
    load_to_database(data)
    logging.info("Everything loaded, all the data is on the db!!")