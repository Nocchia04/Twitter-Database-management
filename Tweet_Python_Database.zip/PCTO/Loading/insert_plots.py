import pymongo


import pymongo
import json


client = pymongo.MongoClient();
mydb = client["twitterdb"]
mycol = mydb["plots"]
    
data = []
filename = "/home/nocchia/Informatica/PCTO/Loading/plots.json"

with open(filename) as f:
    data = json.load(f)  

counter=0
for docs in data:
    mycol.update_many(
        {
            'plot': data[counter]['plot']
        },
        { '$setOnInsert':docs},
        upsert=True
    )
    counter+=1