import pymongo


import pymongo
import json


client = pymongo.MongoClient();
mydb = client["twitterdb"]
mycol = mydb["users"]
    
data = []
filename = "/home/nocchia/Informatica/PCTO/Loading/user.json"

with open(filename) as f:
    data = json.load(f)  

counter=0
for docs in data:
    mycol.update_many(
        {
            'name': data[counter]['name']
        },
        { '$setOnInsert':docs},
        upsert=True
    )
    counter+=1